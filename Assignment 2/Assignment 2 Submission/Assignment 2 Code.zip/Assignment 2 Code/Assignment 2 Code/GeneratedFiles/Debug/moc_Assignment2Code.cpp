/****************************************************************************
** Meta object code from reading C++ file 'Assignment2Code.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Assignment2Code.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Assignment2Code.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Assignment2Code_t {
    QByteArrayData data[39];
    char stringdata0[798];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Assignment2Code_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Assignment2Code_t qt_meta_stringdata_Assignment2Code = {
    {
QT_MOC_LITERAL(0, 0, 15), // "Assignment2Code"
QT_MOC_LITERAL(1, 16, 14), // "PushButtonLoad"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 21), // "PushButtonJPEGEncoder"
QT_MOC_LITERAL(4, 54, 21), // "PushButtonJPEGDecoder"
QT_MOC_LITERAL(5, 76, 20), // "PushButtonJP2Encoder"
QT_MOC_LITERAL(6, 97, 20), // "PushButtonJP2Decoder"
QT_MOC_LITERAL(7, 118, 14), // "PushButtonTest"
QT_MOC_LITERAL(8, 133, 18), // "PushButtonShowDCTY"
QT_MOC_LITERAL(9, 152, 19), // "PushButtonShowDCTCr"
QT_MOC_LITERAL(10, 172, 19), // "PushButtonShowDCTCb"
QT_MOC_LITERAL(11, 192, 18), // "PushButtonShowDCTR"
QT_MOC_LITERAL(12, 211, 18), // "PushButtonShowDCTG"
QT_MOC_LITERAL(13, 230, 18), // "PushButtonShowDCTB"
QT_MOC_LITERAL(14, 249, 18), // "PushButtonShowDWTR"
QT_MOC_LITERAL(15, 268, 18), // "PushButtonShowDWTG"
QT_MOC_LITERAL(16, 287, 18), // "PushButtonShowDWTB"
QT_MOC_LITERAL(17, 306, 27), // "PushButtonShowOriginalImage"
QT_MOC_LITERAL(18, 334, 25), // "PushButtonShowJPEG_262114"
QT_MOC_LITERAL(19, 360, 25), // "PushButtonShowJPEG_131072"
QT_MOC_LITERAL(20, 386, 24), // "PushButtonShowJPEG_65535"
QT_MOC_LITERAL(21, 411, 24), // "PushButtonShowJPEG_16384"
QT_MOC_LITERAL(22, 436, 23), // "PushButtonShowJPEG_8192"
QT_MOC_LITERAL(23, 460, 23), // "PushButtonShowJPEG_4096"
QT_MOC_LITERAL(24, 484, 24), // "PushButtonShowJP2_262114"
QT_MOC_LITERAL(25, 509, 24), // "PushButtonShowJP2_131072"
QT_MOC_LITERAL(26, 534, 23), // "PushButtonShowJP2_65535"
QT_MOC_LITERAL(27, 558, 23), // "PushButtonShowJP2_16384"
QT_MOC_LITERAL(28, 582, 22), // "PushButtonShowJP2_8192"
QT_MOC_LITERAL(29, 605, 22), // "PushButtonShowJP2_4096"
QT_MOC_LITERAL(30, 628, 33), // "PushButtonJPEGProgressiveAnal..."
QT_MOC_LITERAL(31, 662, 20), // "PushButtonJPEGPAPlay"
QT_MOC_LITERAL(32, 683, 32), // "PushButtonJP2ProgressiveAnalysis"
QT_MOC_LITERAL(33, 716, 19), // "PushButtonJP2PAPlay"
QT_MOC_LITERAL(34, 736, 22), // "TextBrowserOutputPrint"
QT_MOC_LITERAL(35, 759, 6), // "output"
QT_MOC_LITERAL(36, 766, 15), // "LabelImagePrint"
QT_MOC_LITERAL(37, 782, 11), // "QByteArray&"
QT_MOC_LITERAL(38, 794, 3) // "rgb"

    },
    "Assignment2Code\0PushButtonLoad\0\0"
    "PushButtonJPEGEncoder\0PushButtonJPEGDecoder\0"
    "PushButtonJP2Encoder\0PushButtonJP2Decoder\0"
    "PushButtonTest\0PushButtonShowDCTY\0"
    "PushButtonShowDCTCr\0PushButtonShowDCTCb\0"
    "PushButtonShowDCTR\0PushButtonShowDCTG\0"
    "PushButtonShowDCTB\0PushButtonShowDWTR\0"
    "PushButtonShowDWTG\0PushButtonShowDWTB\0"
    "PushButtonShowOriginalImage\0"
    "PushButtonShowJPEG_262114\0"
    "PushButtonShowJPEG_131072\0"
    "PushButtonShowJPEG_65535\0"
    "PushButtonShowJPEG_16384\0"
    "PushButtonShowJPEG_8192\0PushButtonShowJPEG_4096\0"
    "PushButtonShowJP2_262114\0"
    "PushButtonShowJP2_131072\0"
    "PushButtonShowJP2_65535\0PushButtonShowJP2_16384\0"
    "PushButtonShowJP2_8192\0PushButtonShowJP2_4096\0"
    "PushButtonJPEGProgressiveAnalysis\0"
    "PushButtonJPEGPAPlay\0"
    "PushButtonJP2ProgressiveAnalysis\0"
    "PushButtonJP2PAPlay\0TextBrowserOutputPrint\0"
    "output\0LabelImagePrint\0QByteArray&\0"
    "rgb"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Assignment2Code[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      34,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  184,    2, 0x0a /* Public */,
       3,    0,  185,    2, 0x0a /* Public */,
       4,    0,  186,    2, 0x0a /* Public */,
       5,    0,  187,    2, 0x0a /* Public */,
       6,    0,  188,    2, 0x0a /* Public */,
       7,    0,  189,    2, 0x0a /* Public */,
       8,    0,  190,    2, 0x0a /* Public */,
       9,    0,  191,    2, 0x0a /* Public */,
      10,    0,  192,    2, 0x0a /* Public */,
      11,    0,  193,    2, 0x0a /* Public */,
      12,    0,  194,    2, 0x0a /* Public */,
      13,    0,  195,    2, 0x0a /* Public */,
      14,    0,  196,    2, 0x0a /* Public */,
      15,    0,  197,    2, 0x0a /* Public */,
      16,    0,  198,    2, 0x0a /* Public */,
      17,    0,  199,    2, 0x0a /* Public */,
      18,    0,  200,    2, 0x0a /* Public */,
      19,    0,  201,    2, 0x0a /* Public */,
      20,    0,  202,    2, 0x0a /* Public */,
      21,    0,  203,    2, 0x0a /* Public */,
      22,    0,  204,    2, 0x0a /* Public */,
      23,    0,  205,    2, 0x0a /* Public */,
      24,    0,  206,    2, 0x0a /* Public */,
      25,    0,  207,    2, 0x0a /* Public */,
      26,    0,  208,    2, 0x0a /* Public */,
      27,    0,  209,    2, 0x0a /* Public */,
      28,    0,  210,    2, 0x0a /* Public */,
      29,    0,  211,    2, 0x0a /* Public */,
      30,    0,  212,    2, 0x0a /* Public */,
      31,    0,  213,    2, 0x0a /* Public */,
      32,    0,  214,    2, 0x0a /* Public */,
      33,    0,  215,    2, 0x0a /* Public */,
      34,    1,  216,    2, 0x0a /* Public */,
      36,    1,  219,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   35,
    QMetaType::Void, 0x80000000 | 37,   38,

       0        // eod
};

void Assignment2Code::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Assignment2Code *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->PushButtonLoad(); break;
        case 1: _t->PushButtonJPEGEncoder(); break;
        case 2: _t->PushButtonJPEGDecoder(); break;
        case 3: _t->PushButtonJP2Encoder(); break;
        case 4: _t->PushButtonJP2Decoder(); break;
        case 5: _t->PushButtonTest(); break;
        case 6: _t->PushButtonShowDCTY(); break;
        case 7: _t->PushButtonShowDCTCr(); break;
        case 8: _t->PushButtonShowDCTCb(); break;
        case 9: _t->PushButtonShowDCTR(); break;
        case 10: _t->PushButtonShowDCTG(); break;
        case 11: _t->PushButtonShowDCTB(); break;
        case 12: _t->PushButtonShowDWTR(); break;
        case 13: _t->PushButtonShowDWTG(); break;
        case 14: _t->PushButtonShowDWTB(); break;
        case 15: _t->PushButtonShowOriginalImage(); break;
        case 16: _t->PushButtonShowJPEG_262114(); break;
        case 17: _t->PushButtonShowJPEG_131072(); break;
        case 18: _t->PushButtonShowJPEG_65535(); break;
        case 19: _t->PushButtonShowJPEG_16384(); break;
        case 20: _t->PushButtonShowJPEG_8192(); break;
        case 21: _t->PushButtonShowJPEG_4096(); break;
        case 22: _t->PushButtonShowJP2_262114(); break;
        case 23: _t->PushButtonShowJP2_131072(); break;
        case 24: _t->PushButtonShowJP2_65535(); break;
        case 25: _t->PushButtonShowJP2_16384(); break;
        case 26: _t->PushButtonShowJP2_8192(); break;
        case 27: _t->PushButtonShowJP2_4096(); break;
        case 28: _t->PushButtonJPEGProgressiveAnalysis(); break;
        case 29: _t->PushButtonJPEGPAPlay(); break;
        case 30: _t->PushButtonJP2ProgressiveAnalysis(); break;
        case 31: _t->PushButtonJP2PAPlay(); break;
        case 32: _t->TextBrowserOutputPrint((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 33: _t->LabelImagePrint((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Assignment2Code::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_Assignment2Code.data,
    qt_meta_data_Assignment2Code,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Assignment2Code::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Assignment2Code::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Assignment2Code.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Assignment2Code::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 34)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 34;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 34)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 34;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
