#include "Assignment1Code.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[]) {
	QApplication a(argc, argv);
	Assignment1Code w;
	w.show();
	return a.exec();
}